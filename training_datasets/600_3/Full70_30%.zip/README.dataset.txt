# My First Project > 2025-09-10 2:45pm
https://universe.roboflow.com/labeling-m0xpq/my-first-project-w0i1s

Provided by a Roboflow user
License: MIT

