# My First Project > 2025-07-25 11:29am
https://universe.roboflow.com/data-aw0ma/my-first-project-taonq

Provided by a Roboflow user
License: CC BY 4.0

