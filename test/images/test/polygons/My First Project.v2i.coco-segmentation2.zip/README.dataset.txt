# My First Project > 2025-07-24 5:58pm
https://universe.roboflow.com/data-aw0ma/my-first-project-taonq

Provided by a Roboflow user
License: CC BY 4.0

