# P1 > 2025-07-24 4:28pm
https://universe.roboflow.com/data-aw0ma/p1-bqn2e

Provided by a Roboflow user
License: CC BY 4.0

